/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import entities.Notifications;
import entities.Reclamation;
import java.awt.Button;
import java.awt.Label;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import services.Ncrud;


/**
 * FXML Controller class
 *
 * @author Maissa
 */
public class NotificationController implements Initializable {
   @FXML
    private TableView<Notifications> tablnotif;
    @FXML
    private TableColumn<Notifications, Integer> id;
    
   
  
    @FXML
    private TableColumn<Notifications, String> idmessage;
  
     @FXML
     private TableColumn<Notifications, Integer> iduser;
    
    @FXML
    private TextField tfnotif;
    @FXML
    private Button btndel;
     @FXML
    private Button btnmodifier;
   
    
        public void showNotif(){
           tablnotif.getItems().clear();
           
     Ncrud pcd= new Ncrud();
     ObservableList<Notifications> data = FXCollections.observableArrayList(pcd.NotificationList());

      id.setCellValueFactory(new PropertyValueFactory<Notifications,Integer> ("id"));
      iduser.setCellValueFactory(new PropertyValueFactory<Notifications,Integer> ("user_id"));
      idmessage.setCellValueFactory(new PropertyValueFactory<Notifications,String> ("message"));
     
    tablnotif.setItems(data); }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        showNotif();
    }    
    
}
