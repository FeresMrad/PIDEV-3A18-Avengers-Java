/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import entities.Reclamation;
import java.awt.Label;
import java.net.URL;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import services.Rcrud;

/**
 * FXML Controller class
 *
 * @author Maissa
 */
public class DelRecController implements Initializable {
    
    
    
    
    @FXML
    private TableView<Reclamation> tablerec;
    @FXML
    private TableColumn<Reclamation, Integer> tfid;
    
    @FXML
     private TableColumn<Reclamation, Integer> tfuser;
  
    @FXML
    private TableColumn<Reclamation, String> tfsubject;
    @FXML
    private TableColumn<Reclamation, String> tfmessage;
    
    @FXML
    private TableColumn<Reclamation, String> tfetat;
    
    
    @FXML
    private Label reclam;
    @FXML
    private TextArea iddescription;
   
    
    
    
    public void showReclam(){
           tablerec.getItems().clear();
           
     Rcrud pcd= new Rcrud();
     ObservableList<Reclamation> data = FXCollections.observableArrayList(pcd.entitiesList());

      tfid.setCellValueFactory(new PropertyValueFactory<Reclamation,Integer> ("id"));
      tfuser.setCellValueFactory(new PropertyValueFactory<Reclamation,Integer> ("user_id"));
      tfsubject.setCellValueFactory(new PropertyValueFactory<Reclamation,String> ("subject"));
      tfmessage.setCellValueFactory(new PropertyValueFactory<Reclamation,String> ("message"));
     tfetat.setCellValueFactory(new PropertyValueFactory<Reclamation,String> ("status"));
    tablerec.setItems(data); }
    
        
        /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        showReclam();
    }    
    private void saveReclamation(){
    
    
    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Ajouter un événement");
        alert.setHeaderText(null);
        alert.setContentText("Êtes-vous sûr de vouloir ajouter cet événement ?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {

            
            int resId = Integer.parseInt(tfid.getText());
            int resUserid = Integer.parseInt(tfuser.getText());
            String resSubj = tfsubject.getText();
            String resMess = tfmessage.getText();
           
          Rcrud pcd = new Rcrud ();

           Reclamation r = new Reclamation(resUserid, resMess, resSubj, resMess);
          
            pcd.addEntity(r);
            System.out.println("Done!!");
            tablerec.getItems().clear();
            showReclam();
        }
    
    
    
    
    
    
    
    
    
    
    
    
    
    }
}
