/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import entities.Reclamation;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import services.Rcrud;
import java.util.*;  
import java.util.*;  
//import javax.mail.*;  
//import javax.mail.internet.*;  
//import javax.activation.*;   

/**
 * FXML Controller class
 *
 * @author Maissa
 */
public class AjouterReclamationController implements Initializable {

    @FXML
    private TextField tfnom;
    @FXML
    private TextArea tfdesc;
    @FXML
    private TextField tfsujet;
    @FXML
    private TextField tfstatus;
    @FXML
    private Button btnadd;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    //private void savePanier(ActionEvent event) {

    public TextField getTfnom() {
        return tfnom;
    }

    public TextArea getTfdesc() {
        return tfdesc;
    }

    public TextField getTfsujet() {
        return tfsujet;
    }

    public TextField getTfstatus() {
        return tfstatus;
    }

    public Button getBtnadd() {
        return btnadd;
    }

    public void setTfnom(TextField tfnom) {
        this.tfnom = tfnom;
    }

    public void setTfdesc(TextArea tfdesc) {
        this.tfdesc = tfdesc;
    }

    public void setTfsujet(TextField tfsujet) {
        this.tfsujet = tfsujet;
    }

    public void setTfstatus(TextField tfstatus) {
        this.tfstatus = tfstatus;
    }

    public void setBtnadd(Button btnadd) {
        this.btnadd = btnadd;
    }
        
        
    
    //}

    @FXML
    private void ajouterReclamation(ActionEvent event) {
        int nom =  Integer.parseInt(tfnom.getText());
          String desc = tfdesc.getText();
          String suj = tfsujet.getText();
          String sub = tfstatus.getText();
        System.out.println(nom);
        Reclamation r = new Reclamation(nom, sub, desc, sub);
       Rcrud pc = new Rcrud();
       
    pc.ajouterReclamation(r);
     Alert alert = new Alert(Alert.AlertType.CONFIRMATION);

                alert.setTitle("Success");
                 //showRecl();
    //redirection
//    //redirection
     FXMLLoader loader = new FXMLLoader(getClass().getResource("Reclamation.fxml"));
           try {
            Parent root = loader.load(); // preparer les acteurs de la 2éme scene
            ReclamationController dc = loader.getController();
           dc.setTfnom(tfnom);
          dc.setTfdescrip(tfdesc);
          dc.setTfsubject(tfsujet);
          dc.setTfstatus(tfstatus);
           
            tfnom.getScene().setRoot(root);// scene loula naawadha b scene thenya eli heya l details
            
        } catch (IOException ex ) {
            
            System.out.println(ex.getMessage());
        }
        
        
    }
//     public void sendMail() {
//        try {
//            String host = "smtp.gmail.com";
//            String user = "yasmine.chaieb@esprit.tn";
//            String pass = "203JFT2277";
//            String to = tfEmail.getText();
//            String from = "yasmine.chaieb@esprit.tn";
//            String subject = "Réclamation traitée";
//            String messageText = "Bonjour cher client  ,votre réclamation a bien été traitée merci. Cordialemment";
//            boolean sessionDebug = false;
//
//            Properties props = System.getProperties();
//
//            props.put("mail.smtp.starttls.enable", "true");
//            props.put("mail.smtp.host", host);
//            props.put("mail.smtp.port", "587");
//            props.put("mail.smtp.auth", "true");
//            props.put("mail.smtp.starttls.required", "true");
//
//            java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
//            Session mailSession = Session.getDefaultInstance(props, null);
//            mailSession.setDebug(sessionDebug);
//            Message msg = new MimeMessage(mailSession);
//            msg.setFrom(new InternetAddress(from));
//            InternetAddress[] address = {new InternetAddress(to)};
//            msg.setRecipients(Message.RecipientType.TO, address);
//            msg.setSubject(subject);
//            msg.setSentDate(new java.util.Date());
//            msg.setText(messageText);
//            javax.mail.Transport transport = mailSession.getTransport("smtp");
//            transport.connect(host, user, pass);
//            transport.sendMessage(msg, msg.getAllRecipients());
//            transport.close();
//            System.out.println("message send successfully");
//        } catch (Exception ex) {
//            System.out.println(ex.getMessage());
//
//        }
   
//    private void saveReclam(ActionEvent event) {
//      int resUserid = Integer.parseInt(tfnom.getText());
//       // String resNom = tfnom.getText();
//            String resDesc = tfdesc.getText();
//     String resStatus= tfstatus.getText();
//     String setTfsubject = tfsujet.getText();
//   
//          Rcrud pcd = new Rcrud();
//          Reclamation r = new Reclamation(resUserid, setTfsubject, resDesc, resStatus);
//        
//          pcd.ajouterReclamation(r);
//     
//        System.out.println("Done!!");
//        }
    



}
    
    
    
    
    
    

