/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import entities.Notifications;
import entities.Reclamation;
//import static entities.Reclamation.Status.attente;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import services.Ncrud;
import services.Rcrud;
import utils.MyConnection;


/**
 *
 * @author Maissa
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
  java.util.Date utilDate = new java.util.Date();
java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());



           DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-mm-dd");
           Date d = new Date(System.currentTimeMillis());
      MyConnection mc = new MyConnection();
    Reclamation r1;
      //  r1 = new Reclamation(3 ,2, "produit", "message", " Attente" ,sqlDate);
       // Reclamation r2 = new Reclamation(4, 7, "produit", "fffff", "dddd");
       Reclamation r3 = new Reclamation(4, "sssss", "sssss", "ssss");
      Rcrud pcd = new Rcrud();
      //ADD
  //pcd.ajouterReclamation(r1);
 //pcd.ajouterReclamation(r3);
  
  //AFFICHAGE
 //pcd.entitiesList();
//
//System.out.println(pcd.entitiesList());
  //DELETE
//findbyid

        System.out.println(pcd.FindReclamationById(23));
  
  
//pcd.suppReclamation(29);
 //UPDATE
// Reclamation r4 = new Reclamation(5, "updqte", "updqte", "updqte");
         
 //pcd.updReclamation(r4, 26);
 
// Notifications n1 = new Notifications ();
//  Notifications n2 = new Notifications(2, 3, "Voici votre notification", "Transaction");
//    
//    Ncrud notif =new  Ncrud();
//    notif.NotificationList();
//        System.out.println(notif.NotificationList());
//      //  notif.addEntity(n2);
//      
//      notif.ajouternotification(n2);
//    notif.suppNotification(n2, 2);// tekhdem 
//    notif.upnotification(n2, 1);//takhdem
    }
    
    
    
}
